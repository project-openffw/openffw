function ed4e = getEd4e(n4e, ed4n)

ed4e = rowaddr(ed4n,n4e(:,[2 3 1]),n4e);

function DbEd  = getDbEdges(Db,ed4n)
DbEd = rowaddr(ed4n,Db(:,1),Db(:,2));
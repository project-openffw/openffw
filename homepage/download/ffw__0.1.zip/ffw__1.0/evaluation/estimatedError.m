function p = estimatedError(p)

% twisted L-shaped domain with a coarse triangulation and no Neumann boundary
% example domain for elasticity
